<?php 

require 'views/login.view.php';

 ?>