<?php
require 'views/registrate.view.php';


  ?>