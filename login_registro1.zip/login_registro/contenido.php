<?php

require 'views\contenido.views.php';

  ?>